class NoneError(Exception):
    pass

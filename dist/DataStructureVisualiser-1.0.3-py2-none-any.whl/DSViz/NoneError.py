class NoneError(Exception):
    pass
